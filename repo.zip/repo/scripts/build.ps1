param(
[string]$version="master-dev"
)

$root = (Get-Item -Path ".\").FullName
$publishDir = $root + "\src\GCapsule.Core\bin\Release\netstandard2.0\publish"
$dist = ".dist"
$version = $version.Trim()
$versionParttern = "^v?(?<master>(?<major>\d{1,5})(?<minor>\.\d+)?(?<patch>\.\d+)?(?<revision>\.\d+)?|master)(?<stability>\-(?:stable|beta|b|RC|alpha|a|patch|pl|p|dev)(?:(?:[.-]?\d+)+)?)?(?<build>\+[0-9A-Za-z\-\.]+)?$"
if(!($version -match $versionParttern))
{
    throw ("Invalid version, must conform to the semver version: " + $version)
}

if($matches["stability"] -eq $null)
{
	$matches["stability"] = "-stable"
}

if($matches["master"] -eq "master")
{
	$matches["major"] = "0"
}

if($matches["minor"] -eq $null)
{
	$matches["minor"] = ".0"
}

if($matches["patch"] -eq $null)
{
	$matches["patch"] = ".0"
}

if($matches["build"] -match "^[0-9a-f]{40}$")
{
	$env:GCAPSULE_COMMIT_SHA = $matches["build"].substring(1).trim()
    $matches["build"] = $matches["build"].substring(0, 8)
}
elseif($env:CI_COMMIT_SHA -ne $null)
{
	$env:GCAPSULE_COMMIT_SHA = ($env:CI_COMMIT_SHA).trim()
	$matches["build"] = "+" + $env:GCAPSULE_COMMIT_SHA.substring(0, 7)
}
else
{
	$env:GCAPSULE_COMMIT_SHA = (git rev-parse HEAD).trim()
	$matches["build"] = "+" + $env:GCAPSULE_COMMIT_SHA.substring(0, 7)
}

$major = $matches["major"]
$minor = $matches["minor"]
$assemblyVersion = $major + ".0.0.0"
$versionNormalized = $major + $minor + $matches["patch"] + $matches["revision"] + $matches["stability"] + $matches["build"]

$beginDateTime = ([DateTime] "01/01/2000");
$midnightDateTime = (Get-Date -Hour 0 -Minute 0 -Second 0);

$elapseDay = -1 * (New-TimeSpan -end $beginDateTime).Days
$elapseMidnight = [math]::floor((New-TimeSpan $midnightDateTime -End (Get-Date)).TotalSeconds * 0.5)
$fileVersion = $major + $minor + "." + $elapseDay + "." + $elapseMidnight

dotnet publish src\GCapsule.Core\GCapsule.Core.csproj -c Release /p:Version=$versionNormalized /p:AssemblyVersion=$assemblyVersion /p:FileVersion=$fileVersion --self-contained false

if($LastExitCode){
	echo "Abnormal. build failded."
	exit(1)
}

if(Test-Path -Path $dist)
{
	Remove-Item $dist -Recurse
}

mkdir $dist
mkdir $dist\netstandard2.0
cp $publishDir\* $dist\netstandard2.0 -Recurse
cp LICENSE $dist
cp README.md $dist
cp bucket.json $dist

$env:GCAPSULE_PROJECT_VERSION=$versionNormalized.trim()
$env:GCAPSULE_FILE_VERSION=$fileVersion.trim()
$env:GCAPSULE_STABILITY=$matches["stability"].substring(1).trim()
$env:GCAPSULE_MIN_DOTNET_CORE="3.0.0".trim()
$env:GCAPSULE_PUBLISH_DIR=$publishDir.trim()

echo "GCAPSULE_COMMIT_SHA $env:GCAPSULE_COMMIT_SHA"
echo "GCAPSULE_FILE_VERSION $env:GCAPSULE_FILE_VERSION"
echo "GCAPSULE_PROJECT_VERSION $env:GCAPSULE_PROJECT_VERSION"
echo "GCAPSULE_STABILITY $env:GCAPSULE_STABILITY"
echo "GCAPSULE_MIN_DOTNET_CORE $env:GCAPSULE_MIN_DOTNET_CORE"
echo "GCAPSULE_PUBLISH_DIR $env:GCAPSULE_PUBLISH_DIR"