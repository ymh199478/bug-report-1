﻿asd
## About GCapsule

`GCapsule` is the lightweight dependency injection container and helper functions library. 

- Service Provider
- Application
- IOC Container
- Facades

## Install GCapsule Core

**Installed with [Bucket](https://git.devcloud.ztgame.com/giant-tech/bucket)**

```shell
$ bucket require gcapsule/core
```

## Learning GCapsule

GCapsule has the most extensive and thorough [documentation](#), making it a breeze to get started with the framework.

## Contribution

GCapsule is still a young framework, and her growth and your contribution are inseparable. If you want to contribute to the project, please refer to: [GCapsule Contribution Guide](#) Your contribution will be included in the list of contributors，Welcome Pull Request!

## License

The open source license used by GCapsule is [MIT license](http://opensource.org/licenses/MIT).

## Support

* issues: https://git.devcloud.ztgame.com/gcapsule/core/-/issues/new
* feishu: yumenghan
